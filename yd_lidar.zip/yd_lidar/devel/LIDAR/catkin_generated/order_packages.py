# generated from catkin/cmake/template/order_packages.context.py.in
source_root_dir = '/home/ssiddharth/ydlidar_ros_ws/src'
whitelisted_packages = ''.split(';') if '' != '' else []
blacklisted_packages = ''.split(';') if '' != '' else []
underlay_workspaces = '/home/ssiddharth/catkin_ws/devel;/opt/ros/noetic'.split(';') if '/home/ssiddharth/catkin_ws/devel;/opt/ros/noetic' != '' else []
