#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH='/home/ssiddharth/ydlidar_ros_ws/devel:/home/ssiddharth/catkin_ws/devel:/opt/ros/noetic'
export LD_LIBRARY_PATH='/home/ssiddharth/catkin_ws/devel/lib:/opt/ros/noetic/lib'
export PKG_CONFIG_PATH='/home/ssiddharth/catkin_ws/devel/lib/pkgconfig:/opt/ros/noetic/lib/pkgconfig'
export PWD='/home/ssiddharth/ydlidar_ros_ws/build'
export ROSLISP_PACKAGE_DIRECTORIES='/home/ssiddharth/ydlidar_ros_ws/devel/share/common-lisp:/home/ssiddharth/catkin_ws/devel/share/common-lisp'
export ROS_PACKAGE_PATH='/home/ssiddharth/ydlidar_ros_ws/src:/home/ssiddharth/catkin_ws/src:/opt/ros/noetic/share'